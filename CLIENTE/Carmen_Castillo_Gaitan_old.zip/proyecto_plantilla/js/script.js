"use strict"

const publico = document.getElementsByClassName("publico");
const privado = document.getElementsByClassName("privado");
const usuario = document.getElementById("nombreUsuario");
const cerrar = document.getElementById("sesion");


function compruebaCookie() {
    const cookies = document.cookie.split("; ");

    for (const c of cookies) {
        const [nombre, clave] = c.split("=");

        if (nombre === "isLoggedIn" && clave === "true") {
            for (const el of publico) {
                el.style.display = "none";
            }
            for (const ele of privado) {
                ele.style.display = "block";
            }
        }

        if (nombre === "usuario" && usuario) {
            usuario.innerHTML = `${clave}`;
        }
    }

}

document.addEventListener("DOMContentLoaded", compruebaCookie);




function borrarCookie() {
    const cookies = document.cookie.split("; ");
    for (const c of cookies) {
        const [nombre, clave] = c.split("=");
        if (nombre === "usuario") {
            document.cookie = `${nombre}=; max-age=0; path=/`;
        }
        if (nombre === "isLoggedIn") {
            document.cookie = `${nombre}="false"; max-age=0; path=/`;
        }
    }
};


cerrar.addEventListener("click", () => {
    borrarCookie();
    for (const el of publico) {
        el.style.display = "block";
    }
    for (const ele of privado) {
        ele.style.display = "none";
    }

});
