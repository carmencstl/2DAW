"use strict"

const mostrarBtn = document.getElementbyId("mostrarBtn");
const ocultarBtn = document.getElementbyId("ocultarBtn");
const mensaje = document.getElementbyId("mensaje");

btnMostrar.addEventListener("click", () =>{
    mensaje.style.display = "block";
});